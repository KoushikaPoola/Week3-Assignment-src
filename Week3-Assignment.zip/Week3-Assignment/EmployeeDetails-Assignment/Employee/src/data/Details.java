package data;

import java.util.Map;
import java.util.TreeMap;

import beans.Employee;

public class Details {
	public Map<String,Employee> map;
	public Details() {
		map = new TreeMap<String,Employee>();
	}
}
