package service;

import beans.User;

public interface RetailService {
	public double calculateBill(User user);
	

}
