package beans;

public enum ProductType {
	GROCERIES,ACCESSORIES;
}
